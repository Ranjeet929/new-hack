Access of Speed 2 Demo by Mikle.

Controls:
 
Accelerate - Up
Decelerate - Down
Turn Left -  Left
Turn Right - Right
Gear Up -    A
Gear Down -  Z
Camera -     C
Exit -       Esc